username = "postgres"
password = ""
host = "localhost"
port = 5432
db_name = "fintech"
opt = f"postgres://{username}:{password}@{host}:{port}/{db_name}"