import pandas as pd
import networkx as nx
from nodevectors import Node2Vec as NVVV
from sklearn.decomposition import PCA
import os, sys, itertools, pickle

def filter_non_esg(df): 
    return df[(df['E']==True) | (df['S'] == True) | (df['G'] == True)]

class graph_creator:
    def __init__(self, df):
        self.df = df

    def create_graph(self):
        # Find Edges
        df_edge = pd.DataFrame(self.df.groupby("URL").Organization.apply(list)
                               ).reset_index()

        get_tpls = lambda r: (list(itertools.combinations(r, 2)) if
                              len(r) > 1 else None)
        df_edge["SourceDest"] = df_edge.Organization.apply(get_tpls)
        df_edge = df_edge.explode("SourceDest").dropna(subset=["SourceDest"])

        # Get Weights
        source_dest = pd.DataFrame(df_edge.SourceDest.tolist(),
                                   columns=["Source", "Dest"])
        sd_mapping = source_dest.groupby(["Source", "Dest"]).size()
        get_weight = lambda r: sd_mapping[r.Source, r.Dest]
        source_dest["weight"] = source_dest.apply(get_weight, axis=1)

        # Get
        self.organizations = set(source_dest.Source.unique()).union(
                             set(source_dest.Dest.unique()))
        self.G = nx.from_pandas_edgelist(source_dest, source="Source",
            target="Dest", edge_attr="weight", create_using=nx.Graph)
        return self.G

def get_embeddings(G, organizations):
    g2v = NVVV()
    g2v.fit(G)
    embeddings = g2v.model.wv.vectors
    pca = PCA(n_components=3)
    principalComponents = pca.fit_transform(embeddings)
    d_e = pd.DataFrame(principalComponents)
    d_e["company"] = organizations
    return d_e, g2v

def get_connections(organizations, g2v,topn=11):
    l = [g2v.model.wv.most_similar(org, topn=topn)
         for org in organizations]
    df_sim = pd.DataFrame(l, columns=[f"n{i}" for i in range(topn)])
    for col in df_sim.columns:
        new_cols = [f"{col}_rec", f"{col}_conf"]
        df_sim[new_cols] = pd.DataFrame(df_sim[col].tolist(), 
                                        index=df_sim.index)
    df_sim = df_sim.drop(columns=[f"n{i}" for i in range(topn)])
    df_sim.insert(0, "company", list(organizations))
    return df_sim

def make_embeddings_and_connections():
    csv_file = sys.argv[1]

    # Load data
    print("Loading Data")
    df = pd.read_csv(csv_file)
    df = filter_non_esg(df)

    # Create graph
    print("Creating Graph")
    creator = graph_creator(df)
    G = creator.create_graph()
    organizations = list(creator.organizations)

    fp = "organization_graph.pkl"
    with open(fp, "wb") as f:
        pickle.dump(G, f)
        
    # Create embeddings
    print("Creating embeddings")
    emb_path = "pca_embeddings.csv"
    d_e, g2v = get_embeddings(G, organizations)
    d_e.to_csv(emb_path, index=False)
    
    # Create connections
    print("Creating connections")
    df_sim = get_connections(organizations, g2v)

    sim_path = "connections.csv"
    df_sim.to_csv(sim_path)


make_embeddings_and_connections()