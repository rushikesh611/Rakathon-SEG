import pandas as pd, sys

data = pd.read_csv(sys.argv[1], parse_dates=["DATE"])

print("Reading data")
organizations = data["Organization"].drop_duplicates().tolist()

def subtract_cols(df, col1, col2):
    df[col1.replace("_tone", "_diff")] = df[col1] - df[col2]
    df.drop(col1, axis=1, inplace=True)
    return df

def daily_tone(df, name):
    colname = f"{name.replace(' ', '_')}_tone"
    return df.groupby("DATE", as_index=False)["Tone"].mean().rename(columns={"DATE":"date", "Tone":colname}).sort_values("date")

def get_col_avgs(df):
    cols_to_consider = list(df.select_dtypes(include=["float64"]).columns)
    return df[cols_to_consider].apply(lambda x:x.mean()).to_dict()

print("Calculating Overall Tone")
overall_tone = daily_tone(data, "industry")

print("Calculating ESG Tone")
esg_tones = {L: daily_tone(data[data[L] == True], "industry") for L in ["E", "S", "G"]} 

pct_idxs = range(0, len(organizations), len(organizations) // 10)

print("Calculating Organization Tone")
for i, org in enumerate(organizations):
    if i in pct_idxs:
        print(f"{pct_idxs.index(i) * 10}%")
    tone_label = f"{org.replace(' ', '_')}_tone"

    overall_org_df = data[data["Organization"] == org]
    
    org_tone = daily_tone(overall_org_df, org)
    
    overall_tone = subtract_cols(overall_tone.merge(org_tone, on="date", how="left"),
                                 tone_label, "industry_tone")

    for L, tdf in esg_tones.items():
        esg_org_df = overall_org_df[overall_org_df[L] == True]
        esg_org_tone = daily_tone(esg_org_df, org)
        esg_tones[L] = subtract_cols(tdf.merge(esg_org_tone, on="date", how="left"), 
                                     tone_label, "industry_tone")

scores = {}
overall_scores = get_col_avgs(overall_tone)
esg_scores = {L: get_col_avgs(tdf) for L, tdf in esg_tones.items()}

for org in organizations:
    diff_label = f"{org.replace(' ', '_')}_diff"
    scores[org] = {L: tdf[diff_label] for L, tdf in esg_scores.items()}
    scores[org]["T"] = overall_scores[diff_label]

print("Saving overall daily esg")
pd_df = overall_tone.set_index("date").sort_index().asfreq(freq="D", method="ffill")
pd_df.to_csv("data/ESG/overall_daily_esg_scores.csv", index=True)

for L, tdf in esg_tones.items():
    print("Saving Daily " + L)
    path = f"data/ESG/daily_{L}_score.csv"
    pd_df = tdf.set_index("date").sort_index().asfreq(freq="D", method="ffill")
    pd_df.to_csv(path, index=True)

print("Saving Average ESG")
score_path = "data/ESG/average_esg_scores.csv"
pd.DataFrame(scores).to_csv(score_path, index=True)