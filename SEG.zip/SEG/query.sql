SELECT
  CAST(CONCAT(subSTRING(CAST(DATE AS string),
      0,
      4), "-",subSTRING(CAST(DATE AS string),
      5,
      2),"-", subSTRING(CAST(DATE AS string),
      7,
      2)) AS DATE) AS DATE,
  SourceCommonName,
  DocumentIdentifier AS URL,
  CASE
    WHEN LOWER(o) LIKE '%twitter%' THEN 'twitter'
    WHEN LOWER(o) LIKE '%pfizer%' THEN 'pfizer'
    WHEN LOWER(o) LIKE '%jpmorgan%' THEN 'jpmorgan'
    WHEN LOWER(o) LIKE '%facebook%' THEN 'facebook'
    WHEN LOWER(o) LIKE '%kroger%' THEN 'kroger'
    WHEN LOWER(o) LIKE '%pepsico%' THEN 'pepsico'
    WHEN LOWER(o) LIKE '%delta air lines%' THEN 'delta air lines'
    WHEN LOWER(o) LIKE '%intel corporation%' THEN 'intel corporation'
    WHEN LOWER(o) LIKE '%netflix inc%' THEN 'netflix inc'
    WHEN LOWER(o) LIKE '%corning%' THEN 'corning'
    WHEN LOWER(o) LIKE '%regeneron%' THEN 'regeneron'
    WHEN LOWER(o) LIKE '%boeing%' THEN 'boeing'
    WHEN LOWER(o) LIKE '%microsoft%' THEN 'microsoft'
    WHEN LOWER(o) LIKE '%advanced micro devices%' THEN 'advanced micro devices'
    WHEN LOWER(o) LIKE '%starbucks%' THEN 'starbucks'
    WHEN LOWER(o) LIKE '%goldman sachs%' THEN 'goldman sachs'
    WHEN LOWER(o) LIKE '%citigroup%' THEN 'citigroup'
    WHEN LOWER(o) LIKE '%united parcel service%' THEN 'united parcel service'
    WHEN LOWER(o) LIKE '%morgan stanley%' THEN 'morgan stanley'
    WHEN LOWER(o) LIKE '%walmart%' THEN 'walmart'
    WHEN LOWER(o) LIKE '%caterpillar inc%' THEN 'caterpillar inc'
    WHEN LOWER(o) LIKE '%northrop grumman%' THEN 'northrop grumman'
    WHEN LOWER(o) LIKE '%lockheed martin%' THEN 'lockheed martin'
    WHEN LOWER(o) LIKE '%cisco systems inc%' THEN 'cisco systems inc'
    WHEN LOWER(o) LIKE '%comcast%' THEN 'comcast'
    WHEN LOWER(o) LIKE '%tesla%' THEN 'tesla'
    WHEN LOWER(o) LIKE '%fedex%' THEN 'fedex'
    WHEN LOWER(o) LIKE '%best buy co%' THEN 'best buy co'
    WHEN LOWER(o) LIKE '%medtronic%' THEN 'medtronic'
    WHEN LOWER(o) LIKE '%abbott lab%' THEN 'abbott lab'
    WHEN LOWER(o) LIKE '%southwest airlines%' THEN 'southwest airlines'
    WHEN LOWER(o) LIKE '%nike inc%' THEN 'nike inc'
    WHEN LOWER(o) LIKE '%apple%' THEN 'apple'
    WHEN LOWER(o) LIKE '%qualcomm%' THEN 'qualcomm'
    WHEN LOWER(o) LIKE '%microchip technology%' THEN 'microchip technology'
    WHEN LOWER(o) LIKE '%mckesson%' THEN 'mckesson'
    WHEN LOWER(o) LIKE '%rockwell automation%' THEN 'rockwell automation'
    WHEN LOWER(o) LIKE '%honeywell corporation%' THEN 'honeywell corporation'
    WHEN LOWER(o) LIKE '%nextera%' THEN 'nextera'
    WHEN LOWER(o) LIKE '%schlumberger%' THEN 'schlumberger'
    WHEN LOWER(o) LIKE '%verizon communications%' THEN 'verizon communications'
    WHEN LOWER(o) LIKE '%nvidia%' THEN 'nvidia'
    WHEN LOWER(o) LIKE '%cognizant technology solutions%' THEN 'cognizant technology solutions'
    WHEN LOWER(o) LIKE '%accenture%' THEN 'accenture'
    WHEN LOWER(o) LIKE '%blackrock%' THEN 'blackrock'
    WHEN LOWER(o) LIKE '%cummins%' THEN 'cummins'
    WHEN LOWER(o) LIKE '%exxon mobil%' THEN 'exxon mobil'
    WHEN LOWER(o) LIKE '%chevron%' THEN 'chevron'
    WHEN LOWER(o) LIKE '%mastercard%' THEN 'mastercard'
    WHEN LOWER(o) LIKE '%dominion energy%' THEN 'dominion energy'
    WHEN LOWER(o) LIKE '%visa inc%' THEN 'visa inc'
    WHEN LOWER(o) LIKE '%eli lilly%' THEN 'eli lilly'
    WHEN LOWER(o) LIKE '%merck%' THEN 'merck'
    WHEN LOWER(o) LIKE '%micron technology%' THEN 'micron technology'
    WHEN LOWER(o) LIKE '%oracle%' THEN 'oracle'
    WHEN LOWER(o) LIKE '%coca cola%' THEN 'coca cola'
    WHEN LOWER(o) LIKE '%wells fargo%' THEN 'wells fargo'
    WHEN LOWER(o) LIKE '%mcdonald corporation%' THEN 'mcdonald corporation'
    WHEN LOWER(o) LIKE '%berkshire hathaway%' THEN 'berkshire hathaway'
    WHEN LOWER(o) LIKE '%palo alto networks%' THEN 'palo alto networks'
    WHEN LOWER(o) LIKE '%clorox%' THEN 'clorox'
    WHEN LOWER(o) LIKE '%johnson controls%' THEN 'johnson controls'
    WHEN LOWER(o) LIKE '%boston scientific%' THEN 'boston scientific'
    WHEN LOWER(o) LIKE '%american express%' THEN 'american express'
    WHEN LOWER(o) LIKE '%general motors%' THEN 'general motors'
    WHEN LOWER(o) LIKE '%mondelez%' THEN 'mondelez'
    WHEN LOWER(o) LIKE '%hp inc%' THEN 'hp inc'
    WHEN LOWER(o) LIKE '%broadcom%' THEN 'broadcom'
    WHEN LOWER(o) LIKE '%gilead sciences%' THEN 'gilead sciences'
    WHEN LOWER(o) LIKE '%charter communications%' THEN 'charter communications'
    WHEN LOWER(o) LIKE '%dollar tree%' THEN 'dollar tree'
    WHEN LOWER(o) LIKE '%conocophillips%' THEN 'conocophillips'
    WHEN LOWER(o) LIKE '%vertex pharmaceutical%' THEN 'vertex pharmaceutical'
    WHEN LOWER(o) LIKE '%agilent technologies%' THEN 'agilent technologies'
    WHEN LOWER(o) LIKE '%dollar general%' THEN 'dollar general'
    WHEN LOWER(o) LIKE '%thermo fisher scientific%' THEN 'thermo fisher scientific'
    WHEN LOWER(o) LIKE '%raytheon technologies%' THEN 'raytheon technologies'
    WHEN LOWER(o) LIKE '%walt disney company%' THEN 'walt disney company'
    WHEN LOWER(o) LIKE '%stryker corp%' THEN 'stryker corp'
    WHEN LOWER(o) LIKE '%alphabet%' THEN 'alphabet'
    WHEN LOWER(o) LIKE '%ford motor%' THEN 'ford motor'
    WHEN LOWER(o) LIKE '%paypal%' THEN 'paypal'
    WHEN LOWER(o) LIKE '%intercontinental exchange%' THEN 'intercontinental exchange'
    WHEN LOWER(o) LIKE '%metlife%' THEN 'metlife'
    WHEN LOWER(o) LIKE '%ebay%' THEN 'ebay'
    WHEN LOWER(o) LIKE '%splunk%' THEN 'splunk'
    WHEN LOWER(o) LIKE '%adobe%' THEN 'adobe'
    WHEN LOWER(o) LIKE '%spotify technology%' THEN 'spotify technology'
    WHEN LOWER(o) LIKE '%electronic arts%' THEN 'electronic arts'
    WHEN LOWER(o) LIKE '%analog devices%' THEN 'analog devices'
    WHEN LOWER(o) LIKE '%uber technologies%' THEN 'uber technologies'
    WHEN LOWER(o) LIKE '%home depot%' THEN 'home depot'
    WHEN LOWER(o) LIKE '%intuit%' THEN 'intuit'
    WHEN LOWER(o) LIKE '%amazon%' THEN 'amazon'
    WHEN LOWER(o) LIKE '%texas instrument%' THEN 'texas instrument'
    WHEN LOWER(o) LIKE '%cerner%' THEN 'cerner'
    WHEN LOWER(o) LIKE '%netapp%' THEN 'netapp'
    WHEN LOWER(o) LIKE '%juniper network%' THEN 'juniper network'
    WHEN LOWER(o) LIKE '%welltower%' THEN 'welltower'
    WHEN LOWER(o) LIKE '%ametek%' THEN 'ametek'
    WHEN LOWER(o) LIKE '%expedia%' THEN 'expedia'
END
  AS Organization,
IF
  (LOWER(themes) LIKE "%env\\_%",
    TRUE,
    FALSE) AS E,
IF
  (LOWER(themes) LIKE "%ungp\\_%",
    TRUE,
    FALSE) AS S,
IF
  (LOWER(themes) LIKE "%econ\\_%",
    TRUE,
    FALSE) AS G,
  CAST(SPLIT(V2Tone, ",")[
OFFSET
  (0)] AS DECIMAL) Tone,
  CAST(SPLIT(V2Tone, ",")[
OFFSET
  (1)] AS DECIMAL) PositiveTone,
  CAST(SPLIT(V2Tone, ",")[
OFFSET
  (2)] AS DECIMAL) NegativeTone,
  CAST(SPLIT(V2Tone, ",")[
OFFSET
  (3)] AS DECIMAL) Polarity,
  CAST(SPLIT(V2Tone, ",")[
OFFSET
  (4)] AS DECIMAL) ActivityDensity,
  CAST(SPLIT(V2Tone, ",")[
OFFSET
  (5)] AS DECIMAL) SelfDensity,
  CAST(SPLIT(V2Tone, ",")[
OFFSET
  (6)] AS int64) WordCount
FROM
  `gdelt-bq.gdeltv2.gkg_partitioned`,
  UNNEST(SPLIT(Organizations, ";")) o
WHERE
  DATE(_PARTITIONTIME) >= "2021-02-07"
  AND (LOWER(themes) LIKE "%env\\_%"
    OR LOWER(themes) LIKE "%ungp\\_%"
    OR LOWER(themes) LIKE "%econ\\_%")
  AND ( LOWER(o) LIKE '%twitter%'
    OR LOWER(o) LIKE '%pfizer%'
    OR LOWER(o) LIKE '%jpmorgan%'
    OR LOWER(o) LIKE '%facebook%'
    OR LOWER(o) LIKE '%kroger%'
    OR LOWER(o) LIKE '%pepsico%'
    OR LOWER(o) LIKE '%delta air lines%'
    OR LOWER(o) LIKE '%intel corporation%'
    OR LOWER(o) LIKE '%netflix inc%'
    OR LOWER(o) LIKE '%corning%'
    OR LOWER(o) LIKE '%regeneron%'
    OR LOWER(o) LIKE '%boeing%'
    OR LOWER(o) LIKE '%microsoft%'
    OR LOWER(o) LIKE '%advanced micro devices%'
    OR LOWER(o) LIKE '%starbucks%'
    OR LOWER(o) LIKE '%goldman sachs%'
    OR LOWER(o) LIKE '%citigroup%'
    OR LOWER(o) LIKE '%united parcel service%'
    OR LOWER(o) LIKE '%morgan stanley%'
    OR LOWER(o) LIKE '%walmart%'
    OR LOWER(o) LIKE '%caterpillar inc%'
    OR LOWER(o) LIKE '%northrop grumman%'
    OR LOWER(o) LIKE '%lockheed martin%'
    OR LOWER(o) LIKE '%cisco systems inc%'
    OR LOWER(o) LIKE '%comcast%'
    OR LOWER(o) LIKE '%tesla%'
    OR LOWER(o) LIKE '%fedex%'
    OR LOWER(o) LIKE '%best buy co%'
    OR LOWER(o) LIKE '%medtronic%'
    OR LOWER(o) LIKE '%abbott lab%'
    OR LOWER(o) LIKE '%southwest airlines%'
    OR LOWER(o) LIKE '%nike inc%'
    OR LOWER(o) LIKE '%apple%'
    OR LOWER(o) LIKE '%qualcomm%'
    OR LOWER(o) LIKE '%microchip technology%'
    OR LOWER(o) LIKE '%mckesson%'
    OR LOWER(o) LIKE '%rockwell automation%'
    OR LOWER(o) LIKE '%honeywell corporation%'
    OR LOWER(o) LIKE '%nextera%'
    OR LOWER(o) LIKE '%schlumberger%'
    OR LOWER(o) LIKE '%verizon communications%'
    OR LOWER(o) LIKE '%nvidia%'
    OR LOWER(o) LIKE '%cognizant technology solutions%'
    OR LOWER(o) LIKE '%accenture%'
    OR LOWER(o) LIKE '%blackrock%'
    OR LOWER(o) LIKE '%cummins%'
    OR LOWER(o) LIKE '%exxon mobil%'
    OR LOWER(o) LIKE '%chevron%'
    OR LOWER(o) LIKE '%mastercard%'
    OR LOWER(o) LIKE '%dominion energy%'
    OR LOWER(o) LIKE '%visa inc%'
    OR LOWER(o) LIKE '%eli lilly%'
    OR LOWER(o) LIKE '%merck%'
    OR LOWER(o) LIKE '%micron technology%'
    OR LOWER(o) LIKE '%oracle%'
    OR LOWER(o) LIKE '%coca cola%'
    OR LOWER(o) LIKE '%wells fargo%'
    OR LOWER(o) LIKE '%mcdonald corporation%'
    OR LOWER(o) LIKE '%berkshire hathaway%'
    OR LOWER(o) LIKE '%palo alto networks%'
    OR LOWER(o) LIKE '%clorox%'
    OR LOWER(o) LIKE '%johnson controls%'
    OR LOWER(o) LIKE '%boston scientific%'
    OR LOWER(o) LIKE '%american express%'
    OR LOWER(o) LIKE '%general motors%'
    OR LOWER(o) LIKE '%mondelez%'
    OR LOWER(o) LIKE '%hp inc%'
    OR LOWER(o) LIKE '%broadcom%'
    OR LOWER(o) LIKE '%gilead sciences%'
    OR LOWER(o) LIKE '%charter communications%'
    OR LOWER(o) LIKE '%dollar tree%'
    OR LOWER(o) LIKE '%conocophillips%'
    OR LOWER(o) LIKE '%vertex pharmaceutical%'
    OR LOWER(o) LIKE '%agilent technologies%'
    OR LOWER(o) LIKE '%dollar general%'
    OR LOWER(o) LIKE '%thermo fisher scientific%'
    OR LOWER(o) LIKE '%raytheon technologies%'
    OR LOWER(o) LIKE '%walt disney company%'
    OR LOWER(o) LIKE '%stryker corp%'
    OR LOWER(o) LIKE '%alphabet%'
    OR LOWER(o) LIKE '%ford motor%'
    OR LOWER(o) LIKE '%paypal%'
    OR LOWER(o) LIKE '%intercontinental exchange%'
    OR LOWER(o) LIKE '%metlife%'
    OR LOWER(o) LIKE '%ebay%'
    OR LOWER(o) LIKE '%splunk%'
    OR LOWER(o) LIKE '%adobe%'
    OR LOWER(o) LIKE '%spotify technology%'
    OR LOWER(o) LIKE '%electronic arts%'
    OR LOWER(o) LIKE '%analog devices%'
    OR LOWER(o) LIKE '%uber technologies%'
    OR LOWER(o) LIKE '%home depot%'
    OR LOWER(o) LIKE '%intuit%'
    OR LOWER(o) LIKE '%amazon%'
    OR LOWER(o) LIKE '%texas instrument%'
    OR LOWER(o) LIKE '%cerner%'
    OR LOWER(o) LIKE '%netapp%'
    OR LOWER(o) LIKE '%juniper network%'
    OR LOWER(o) LIKE '%welltower%'
    OR LOWER(o) LIKE '%ametek%'
    OR LOWER(o) LIKE '%expedia%' )