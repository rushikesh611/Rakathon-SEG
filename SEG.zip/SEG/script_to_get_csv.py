# https://www.youtube.com/watch?v=9fjs8FeLMJk

import pandas as pd

from pandas_datareader import data as web

assets = ["FB", "AMZN", "AAPL", "NFLX", "GOOG"]

start_date = "2013-01-01"
end_date = "2021-03-12"

df = pd.DataFrame()

for stock in assets:
    df[stock] = web.DataReader(stock, data_source="yahoo", start=start_date, end=end_date)["Adj Close"]

df.reset_index().to_csv("SP100index.csv", index=False)